<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<?php include('admin-header.php'); ?>
	<div class="container-fluid mt-3">
		<div class="row">
			<?php include('admin-leftsidebar.php'); ?>	
			<div class="col-sm-8  border border-2 border-dark shadow">
				<h3 class="text-center"><u>User Requests</u></h3>
			</div>		
			<?php include('admin-rightsidebar.php'); ?>
			
		</div>
	</div>
</body>
</html>