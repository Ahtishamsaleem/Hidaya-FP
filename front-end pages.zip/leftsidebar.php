<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
	
</head>
<body>
	<div class="col-sm-2 border border-dark border-1 shadow lead">
 				<ul>
 					<li style="font-size: 30px; list-style: none; text-decoration:underline;">Latest Posts</li>
 					<li>News</li>
 					<li>Sports</li>
 					<li>Bussiness</li>
 					<li>Education</li>
 					<li>Entertainment</li>
 					<li>Science & Technology</li>
 				</ul>
 			</div>
</body>
</html>