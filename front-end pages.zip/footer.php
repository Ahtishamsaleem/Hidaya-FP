<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<!-- footer bar -->
		<div class="position-abosulte">
			<div class="container bg-dark mt-3 text-center " style="color: darkgrey;">
				<div class="row">
					<div class="col-lg-12">
						Copyright ©2022 All rights reserved | Pak Solar Engineering Work Since 1980's World Class Engineer(Sanghar)
					</div>
				</div>
			</div>
		</div>
</body>
</html>