<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
	<script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</head>
<body>
	<div class="col-sm-2 border border-dark border-1 shadow lead">
 				<ul>
 					<li style="font-size: 30px; list-style: none; text-decoration: underline;">Catogroies</li>
 					<li>Political</li>
 					<li>Mobile Prices</li>
 					<li>New IT Parks</li>
 					<li>Weather Update</li>
 					<li>POST Graduation Scholarships</li>
 					<li>Trending Education News</li>
 				</ul>
 			</div>
</body>
</html>