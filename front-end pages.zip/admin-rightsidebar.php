<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<div class="col-sm-2 border border-1 border-dark shadow rounded">
				<ul >
					<li style="list-style: none; font-size: 20px;">Latest Posts</li>
					<li>hello world</li>
					<li>hello world</li>
					<li>hello world</li>
					<li>hello world</li>
					<li>hello world</li>
				</ul>
			</div>

</body>
</html>