<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	   <div class="container-fluid">
		<div class="row">
			<div class="col-sm-12 bg-dark">
				<h2 class="text-center text-light">Welcome To Admin Dashboard</h2>
			</div>
			<div class="col-sm-12 bg-secondary">
							<h3 class=" text-light">
								<img src="images/logo_icon.png" style="width: 5%;height: 60px;">
								Online Blogging Application
								<p style="float: right; margin-top: 10px;">
									Admin Name
								<img src="images/profile.jpg" style="width: 15%; height: 50px;">
								</p>
							</h3>
			</div>
		</div>
	</div>
</body>
</html>